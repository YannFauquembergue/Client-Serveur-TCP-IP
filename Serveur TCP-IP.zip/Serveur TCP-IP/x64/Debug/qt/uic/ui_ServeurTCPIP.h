/********************************************************************************
** Form generated from reading UI file 'ServeurTCPIP.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SERVEURTCPIP_H
#define UI_SERVEURTCPIP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ServeurTCPIPClass
{
public:
    QWidget *centralWidget;
    QGroupBox *listenGroup;
    QLabel *portLabel;
    QPushButton *listenButton;
    QLineEdit *portLine;
    QLabel *listenStatus;
    QPlainTextEdit *logBox;
    QLabel *logLabel;
    QPushButton *logClearButton;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *ServeurTCPIPClass)
    {
        if (ServeurTCPIPClass->objectName().isEmpty())
            ServeurTCPIPClass->setObjectName(QString::fromUtf8("ServeurTCPIPClass"));
        ServeurTCPIPClass->resize(301, 400);
        centralWidget = new QWidget(ServeurTCPIPClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        listenGroup = new QGroupBox(centralWidget);
        listenGroup->setObjectName(QString::fromUtf8("listenGroup"));
        listenGroup->setGeometry(QRect(10, 10, 281, 331));
        portLabel = new QLabel(listenGroup);
        portLabel->setObjectName(QString::fromUtf8("portLabel"));
        portLabel->setGeometry(QRect(10, 30, 21, 20));
        portLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        listenButton = new QPushButton(listenGroup);
        listenButton->setObjectName(QString::fromUtf8("listenButton"));
        listenButton->setGeometry(QRect(100, 30, 101, 21));
        listenButton->setCursor(QCursor(Qt::PointingHandCursor));
        portLine = new QLineEdit(listenGroup);
        portLine->setObjectName(QString::fromUtf8("portLine"));
        portLine->setGeometry(QRect(40, 30, 51, 21));
        portLine->setAlignment(Qt::AlignCenter);
        listenStatus = new QLabel(listenGroup);
        listenStatus->setObjectName(QString::fromUtf8("listenStatus"));
        listenStatus->setGeometry(QRect(10, 50, 261, 31));
        QFont font;
        font.setBold(false);
        font.setWeight(50);
        listenStatus->setFont(font);
        listenStatus->setScaledContents(false);
        listenStatus->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        listenStatus->setWordWrap(false);
        logBox = new QPlainTextEdit(listenGroup);
        logBox->setObjectName(QString::fromUtf8("logBox"));
        logBox->setGeometry(QRect(10, 120, 261, 201));
        logBox->setReadOnly(true);
        logLabel = new QLabel(listenGroup);
        logLabel->setObjectName(QString::fromUtf8("logLabel"));
        logLabel->setGeometry(QRect(10, 90, 261, 21));
        logLabel->setFont(font);
        logClearButton = new QPushButton(listenGroup);
        logClearButton->setObjectName(QString::fromUtf8("logClearButton"));
        logClearButton->setGeometry(QRect(170, 90, 101, 21));
        logClearButton->setCursor(QCursor(Qt::PointingHandCursor));
        ServeurTCPIPClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(ServeurTCPIPClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 301, 20));
        ServeurTCPIPClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(ServeurTCPIPClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        ServeurTCPIPClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(ServeurTCPIPClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        ServeurTCPIPClass->setStatusBar(statusBar);

        retranslateUi(ServeurTCPIPClass);
        QObject::connect(listenButton, SIGNAL(clicked()), ServeurTCPIPClass, SLOT(OnListenButtonClicked()));
        QObject::connect(logClearButton, SIGNAL(clicked()), ServeurTCPIPClass, SLOT(OnLogClearButtonClicked()));

        QMetaObject::connectSlotsByName(ServeurTCPIPClass);
    } // setupUi

    void retranslateUi(QMainWindow *ServeurTCPIPClass)
    {
        ServeurTCPIPClass->setWindowTitle(QCoreApplication::translate("ServeurTCPIPClass", "ServeurTCPIP", nullptr));
        listenGroup->setTitle(QCoreApplication::translate("ServeurTCPIPClass", "Serveur", nullptr));
        portLabel->setText(QCoreApplication::translate("ServeurTCPIPClass", "Port", nullptr));
        listenButton->setText(QCoreApplication::translate("ServeurTCPIPClass", "Mettre en \303\251coute", nullptr));
        listenStatus->setText(QCoreApplication::translate("ServeurTCPIPClass", "Etat serveur : HS", nullptr));
        logBox->setPlainText(QString());
        logLabel->setText(QCoreApplication::translate("ServeurTCPIPClass", "Log", nullptr));
        logClearButton->setText(QCoreApplication::translate("ServeurTCPIPClass", "Effacer le log", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ServeurTCPIPClass: public Ui_ServeurTCPIPClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SERVEURTCPIP_H

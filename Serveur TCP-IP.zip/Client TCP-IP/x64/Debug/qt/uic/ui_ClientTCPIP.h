/********************************************************************************
** Form generated from reading UI file 'ClientTCPIP.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLIENTTCPIP_H
#define UI_CLIENTTCPIP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ClientTCPIPClass
{
public:
    QWidget *centralWidget;
    QGroupBox *tempGroup;
    QComboBox *tempCombo;
    QLabel *tempLabel;
    QLabel *sensorLabel;
    QPushButton *getButton;
    QPlainTextEdit *dataBox;
    QLabel *dataLabel;
    QLineEdit *sensorLine;
    QGroupBox *connectGroup;
    QLabel *portLabel;
    QLabel *ipLabel;
    QPushButton *connectButton;
    QLineEdit *ipLine;
    QLineEdit *portLine;
    QLabel *connectStatus;
    QLabel *errorLabel;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *ClientTCPIPClass)
    {
        if (ClientTCPIPClass->objectName().isEmpty())
            ClientTCPIPClass->setObjectName(QString::fromUtf8("ClientTCPIPClass"));
        ClientTCPIPClass->resize(600, 400);
        centralWidget = new QWidget(ClientTCPIPClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        tempGroup = new QGroupBox(centralWidget);
        tempGroup->setObjectName(QString::fromUtf8("tempGroup"));
        tempGroup->setGeometry(QRect(300, 10, 291, 331));
        tempCombo = new QComboBox(tempGroup);
        tempCombo->addItem(QString());
        tempCombo->addItem(QString());
        tempCombo->addItem(QString());
        tempCombo->setObjectName(QString::fromUtf8("tempCombo"));
        tempCombo->setGeometry(QRect(80, 60, 121, 21));
        tempLabel = new QLabel(tempGroup);
        tempLabel->setObjectName(QString::fromUtf8("tempLabel"));
        tempLabel->setGeometry(QRect(10, 60, 61, 21));
        tempLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        sensorLabel = new QLabel(tempGroup);
        sensorLabel->setObjectName(QString::fromUtf8("sensorLabel"));
        sensorLabel->setGeometry(QRect(10, 30, 61, 21));
        sensorLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        getButton = new QPushButton(tempGroup);
        getButton->setObjectName(QString::fromUtf8("getButton"));
        getButton->setGeometry(QRect(80, 90, 121, 31));
        getButton->setCursor(QCursor(Qt::PointingHandCursor));
        dataBox = new QPlainTextEdit(tempGroup);
        dataBox->setObjectName(QString::fromUtf8("dataBox"));
        dataBox->setGeometry(QRect(10, 150, 271, 171));
        dataBox->setReadOnly(true);
        dataBox->setTextInteractionFlags(Qt::TextSelectableByMouse);
        dataLabel = new QLabel(tempGroup);
        dataLabel->setObjectName(QString::fromUtf8("dataLabel"));
        dataLabel->setGeometry(QRect(10, 130, 261, 21));
        sensorLine = new QLineEdit(tempGroup);
        sensorLine->setObjectName(QString::fromUtf8("sensorLine"));
        sensorLine->setGeometry(QRect(80, 30, 121, 21));
        connectGroup = new QGroupBox(centralWidget);
        connectGroup->setObjectName(QString::fromUtf8("connectGroup"));
        connectGroup->setGeometry(QRect(10, 10, 281, 331));
        portLabel = new QLabel(connectGroup);
        portLabel->setObjectName(QString::fromUtf8("portLabel"));
        portLabel->setGeometry(QRect(10, 60, 61, 20));
        portLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ipLabel = new QLabel(connectGroup);
        ipLabel->setObjectName(QString::fromUtf8("ipLabel"));
        ipLabel->setGeometry(QRect(10, 30, 61, 20));
        ipLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        connectButton = new QPushButton(connectGroup);
        connectButton->setObjectName(QString::fromUtf8("connectButton"));
        connectButton->setGeometry(QRect(80, 90, 111, 31));
        connectButton->setCursor(QCursor(Qt::PointingHandCursor));
        ipLine = new QLineEdit(connectGroup);
        ipLine->setObjectName(QString::fromUtf8("ipLine"));
        ipLine->setGeometry(QRect(80, 30, 111, 21));
        portLine = new QLineEdit(connectGroup);
        portLine->setObjectName(QString::fromUtf8("portLine"));
        portLine->setGeometry(QRect(80, 60, 51, 21));
        portLine->setAlignment(Qt::AlignCenter);
        connectStatus = new QLabel(connectGroup);
        connectStatus->setObjectName(QString::fromUtf8("connectStatus"));
        connectStatus->setGeometry(QRect(10, 130, 261, 21));
        QFont font;
        font.setBold(false);
        font.setWeight(50);
        connectStatus->setFont(font);
        errorLabel = new QLabel(connectGroup);
        errorLabel->setObjectName(QString::fromUtf8("errorLabel"));
        errorLabel->setGeometry(QRect(10, 150, 261, 21));
        errorLabel->setFont(font);
        ClientTCPIPClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(ClientTCPIPClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 600, 20));
        ClientTCPIPClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(ClientTCPIPClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        ClientTCPIPClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(ClientTCPIPClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        ClientTCPIPClass->setStatusBar(statusBar);

        retranslateUi(ClientTCPIPClass);
        QObject::connect(connectButton, SIGNAL(clicked()), ClientTCPIPClass, SLOT(OnConnectButtonClicked()));
        QObject::connect(getButton, SIGNAL(clicked()), ClientTCPIPClass, SLOT(OnGetTempButtonClicked()));

        QMetaObject::connectSlotsByName(ClientTCPIPClass);
    } // setupUi

    void retranslateUi(QMainWindow *ClientTCPIPClass)
    {
        ClientTCPIPClass->setWindowTitle(QCoreApplication::translate("ClientTCPIPClass", "ClientTCPIP", nullptr));
        tempGroup->setTitle(QCoreApplication::translate("ClientTCPIPClass", "Temp\303\251rature", nullptr));
        tempCombo->setItemText(0, QCoreApplication::translate("ClientTCPIPClass", "Temp\303\251rature en \302\260C", nullptr));
        tempCombo->setItemText(1, QCoreApplication::translate("ClientTCPIPClass", "Temp\303\251rature en \302\260F", nullptr));
        tempCombo->setItemText(2, QCoreApplication::translate("ClientTCPIPClass", "Hygrom\303\251trie", nullptr));

        tempLabel->setText(QCoreApplication::translate("ClientTCPIPClass", "R\303\251cup\303\251rer", nullptr));
        sensorLabel->setText(QCoreApplication::translate("ClientTCPIPClass", "Capteur", nullptr));
        getButton->setText(QCoreApplication::translate("ClientTCPIPClass", "R\303\251cup\303\251rer", nullptr));
        dataBox->setPlainText(QString());
        dataLabel->setText(QCoreApplication::translate("ClientTCPIPClass", "Donn\303\251es r\303\251cup\303\251r\303\251es", nullptr));
        sensorLine->setText(QCoreApplication::translate("ClientTCPIPClass", "01", nullptr));
        connectGroup->setTitle(QCoreApplication::translate("ClientTCPIPClass", "Connexion", nullptr));
        portLabel->setText(QCoreApplication::translate("ClientTCPIPClass", "Port", nullptr));
        ipLabel->setText(QCoreApplication::translate("ClientTCPIPClass", "Adresse IP", nullptr));
        connectButton->setText(QCoreApplication::translate("ClientTCPIPClass", "Connexion", nullptr));
        connectStatus->setText(QCoreApplication::translate("ClientTCPIPClass", "Etat connexion : D\303\251connect\303\251", nullptr));
        errorLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class ClientTCPIPClass: public Ui_ClientTCPIPClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLIENTTCPIP_H
